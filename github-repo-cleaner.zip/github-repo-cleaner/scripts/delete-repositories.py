import os
import sys
import requests

TOKEN = os.environ["GITHUB_TOKEN"]
CONFIRMATION = os.environ.get("CONFIRMATION", "")
DRY_RUN = os.environ.get("DRY_RUN", "true").lower() == "true"

if CONFIRMATION != "DELETE ALL REPOSITORIES":
    print("Deletion not authorized.")
    print("Required confirmation: DELETE ALL REPOSITORIES")
    sys.exit(1)

session = requests.Session()
session.headers.update({
    "Authorization": f"Bearer {TOKEN}",
    "Accept": "application/vnd.github+json",
    "X-GitHub-Api-Version": "2022-11-28",
})

user = session.get("https://api.github.com/user")
user.raise_for_status()
username = user.json()["login"]

repos = []
page = 1

while True:
    response = session.get(
        "https://api.github.com/user/repos",
        params={"per_page": 100, "page": page, "affiliation": "owner"},
    )
    response.raise_for_status()
    batch = response.json()
    if not batch:
        break
    repos.extend(batch)
    page += 1

print(f"Account: {username}")
print(f"Repositories found: {len(repos)}")

for repo in repos:
    full_name = repo["full_name"]
    visibility = repo["visibility"]

    print(f"[{'DRY RUN' if DRY_RUN else 'DELETE'}] {full_name} ({visibility})")

    if DRY_RUN:
        continue

    result = session.delete(f"https://api.github.com/repos/{full_name}")

    if result.status_code == 204:
        print(f"Deleted: {full_name}")
    else:
        print(f"FAILED: {full_name} HTTP {result.status_code}: {result.text}")
