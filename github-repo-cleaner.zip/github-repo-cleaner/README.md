# GitHub Repository Cleanup Action

Deletes repositories owned by the authenticated GitHub account through the GitHub API.

## Safety

The workflow is manual and defaults to dry-run mode. It requires the exact confirmation:

`DELETE ALL REPOSITORIES`

Never put a GitHub token directly in source code or workflow files.

## Setup

1. Upload this project to a GitHub repository.
2. Create a GitHub token with the minimum repository-management permissions required.
3. Add it as an Actions secret named `REPO_ADMIN_TOKEN`.
4. Open **Actions → Repository Cleanup → Run workflow**.
5. Keep `dry_run=true` first to verify the repository list.
6. Only if the list is correct, run again with `dry_run=false` and the exact confirmation phrase.

Deletion is destructive and may not be recoverable. The control repository can also be deleted if it is owned by the authenticated account.
