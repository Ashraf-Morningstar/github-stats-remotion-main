# Delete All Repositories (GitHub Action)

Deletes all public and private repositories under your account via a manually triggered workflow.

**Deletion is permanent. Back up anything you need first.**

## Setup
1. Create a classic Personal Access Token (GitHub > Settings > Developer settings > Tokens (classic)) with `repo` and `delete_repo` scopes.
2. Create a new GitHub repo and upload the contents of this folder (keep the `.github/workflows` path).
3. In the repo: Settings > Secrets and variables > Actions > New secret. Name: `GH_DELETE_TOKEN`, value: your token.
4. Go to the Actions tab > "Delete All Repositories" > Run workflow.
   - First run with `dry_run = true` to see the list.
   - Then run with `dry_run = false` and confirm = `DELETE-ALL-MY-REPOS`.

## Options
- `keep`: comma-separated repo names to skip.
- `delete_this_repo`: also deletes this repo at the end.

## Notes
- For an organization, replace `"$OWNER"` in the `gh repo list` line with the org name (token needs org admin rights).
- Revoke the token when finished.
